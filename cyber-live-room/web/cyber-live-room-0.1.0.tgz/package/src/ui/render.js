const { estimateActiveTokens } = window.CLRRoomEngine;
const { escapeAttr, escapeHTML, formatTime, initials } = window.CLRUtils;

function render(state, els) {
  renderStatus(state, els);
  renderAudience(state, els);
  renderTranscript(state, els);
  renderConfig(state, els);
  renderMemory(state, els);
}

window.CLRRender = {
  render
};

function renderStatus(state, els) {
  const enabled = state.models.filter((model) => model.enabled);
  const liveModels = enabled.filter((model) => model.apiKey || model.endpoint);
  const tokenEstimate = estimateActiveTokens(state);
  els.liveStatus.textContent = liveModels.length ? "Live API enabled" : "Offline simulation";
  els.modelCount.textContent = `${state.models.length} models`;
  els.memoryCount.textContent = `${state.memories.length} memories`;
  els.enabledCount.textContent = `${enabled.length} enabled`;
  els.tokenEstimate.textContent = `${tokenEstimate} tokens`;
  els.tokenBudgetLabel.textContent = `${state.settings.tokenBudget} tokens`;
  els.summaryCount.textContent = String(state.summaries.length);
}

function renderAudience(state, els) {
  const models = state.models;
  const enabled = models.filter((model) => model.enabled);

  els.modelRail.innerHTML = models.length
    ? models
        .map(
          (model) => `
            <article class="model-pill" style="opacity:${model.enabled ? "1" : "0.48"}">
              <div class="model-dot" style="color:${escapeAttr(model.color)}">${escapeHTML(initials(model.name))}</div>
              <div>
                <strong>${escapeHTML(model.name)}</strong>
                <small>${escapeHTML(model.provider)} / ${escapeHTML(model.modelId || "simulation")}</small>
              </div>
            </article>
          `
        )
        .join("")
    : `<p class="empty-state">No models configured yet.</p>`;

  els.audienceOrbits.innerHTML = enabled
    .map((model, index) => {
      const angle = (Math.PI * 2 * index) / Math.max(enabled.length, 1) - Math.PI / 2;
      const x = 50 + Math.cos(angle) * 36;
      const y = 50 + Math.sin(angle) * 34;
      return `
        <div class="orbit-avatar" style="left:${x}%;top:${y}%;color:${escapeAttr(model.color)}">
          ${escapeHTML(initials(model.name))}
        </div>
      `;
    })
    .join("");
}

function renderTranscript(state, els) {
  els.transcript.innerHTML = state.messages.length
    ? state.messages
        .map(
          (message) => `
            <article class="message ${escapeAttr(message.kind)}" style="border-left-color:${escapeAttr(message.color || "#384250")}">
              <div class="message-meta">
                <span class="message-author">${escapeHTML(message.author)}</span>
                <span>${escapeHTML(message.provider || message.kind)} / ${formatTime(message.createdAt)}</span>
              </div>
              <p>${escapeHTML(message.text)}</p>
            </article>
          `
        )
        .join("")
    : `<p class="empty-state">The room is quiet. Send a host broadcast to start the discussion.</p>`;
}

function renderConfig(state, els) {
  els.configuredModels.innerHTML = state.models.length
    ? state.models
        .map(
          (model) => `
            <article class="model-config-card">
              <div class="model-card-header">
                <div>
                  <strong>${escapeHTML(model.name)}</strong>
                  <small>${escapeHTML(model.provider)} / ${escapeHTML(model.modelId || "simulation")}</small>
                </div>
                <div class="model-dot" style="color:${escapeAttr(model.color)}">${escapeHTML(initials(model.name))}</div>
              </div>
              <p class="muted">${escapeHTML(model.persona)}</p>
              <small>Endpoint: ${escapeHTML(model.endpoint || "simulation adapter")}</small>
              <small>API key: ${model.apiKey ? "configured" : "not set"}</small>
              <div class="model-actions">
                <button data-action="edit" data-id="${escapeAttr(model.id)}" type="button">Edit</button>
                <button data-action="toggle" data-id="${escapeAttr(model.id)}" type="button">
                  ${model.enabled ? "Disable" : "Enable"}
                </button>
                <button data-action="delete" data-id="${escapeAttr(model.id)}" type="button">Delete</button>
              </div>
            </article>
          `
        )
        .join("")
    : `<p class="empty-state">No configured models.</p>`;
}

function renderMemory(state, els) {
  els.memoryList.innerHTML = state.memories.length
    ? state.memories
        .map(
          (memory) => `
            <article class="memory-card">
              <p>${escapeHTML(memory.text)}</p>
              <small>${escapeHTML(memory.source)} / ${formatTime(memory.createdAt)}</small>
              <div class="model-actions">
                <button data-id="${escapeAttr(memory.id)}" type="button">Forget</button>
              </div>
            </article>
          `
        )
        .join("")
    : `<p class="empty-state">No durable memory saved.</p>`;

  els.summaryList.innerHTML = state.summaries.length
    ? state.summaries
        .slice()
        .reverse()
        .map(
          (summary) => `
            <article class="summary-card">
              <p>${escapeHTML(summary.text)}</p>
              <small>${summary.messageCount} messages / ${formatTime(summary.createdAt)}</small>
            </article>
          `
        )
        .join("")
    : `<p class="empty-state">No compressed summaries yet.</p>`;
}
