(() => {
const STORAGE_KEYS = {
  models: "clr.models.v1",
  messages: "clr.messages.v1",
  memories: "clr.memories.v1",
  summaries: "clr.summaries.v1",
  settings: "clr.settings.v1"
};

const DEFAULT_MODELS = [
  {
    id: "model-strategist",
    name: "Strategist",
    provider: "OpenAI",
    modelId: "gpt-discussion",
    endpoint: "",
    apiKey: "",
    persona: "Product strategist focused on user value, positioning, and next steps.",
    temperature: 0.7,
    color: "#39a0ff",
    enabled: true
  },
  {
    id: "model-engineer",
    name: "Engineer",
    provider: "Anthropic",
    modelId: "claude-discussion",
    endpoint: "",
    apiKey: "",
    persona: "Senior engineer focused on architecture, edge cases, and implementation risk.",
    temperature: 0.45,
    color: "#ff7a45",
    enabled: true
  },
  {
    id: "model-critic",
    name: "Critic",
    provider: "Google",
    modelId: "gemini-discussion",
    endpoint: "",
    apiKey: "",
    persona: "Adversarial reviewer focused on gaps, weak assumptions, and missing evidence.",
    temperature: 0.6,
    color: "#9b7cff",
    enabled: true
  }
];

const DEFAULT_SETTINGS = {
  tokenBudget: 900,
  discussionRounds: 2
};

const DEFAULT_MEMORY_TEXT =
  "The host prefers concrete tradeoffs, clear recommendations, and implementation-ready discussion.";

window.CLRDefaults = {
  STORAGE_KEYS,
  DEFAULT_MODELS,
  DEFAULT_SETTINGS,
  DEFAULT_MEMORY_TEXT
};
})();
