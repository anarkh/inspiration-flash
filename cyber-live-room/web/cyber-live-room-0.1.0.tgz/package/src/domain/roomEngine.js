(() => {
const { estimateTokens, shorten, topKeywords, uid } = window.CLRUtils;
const { callModel, hasRuntimeConfig } = window.CLRProviderAdapters;

function addMessage(state, partial) {
  const message = {
    id: uid("msg"),
    createdAt: Date.now(),
    ...partial
  };
  state.messages.push(message);
  return message;
}

async function runDiscussion(state, hostText, enabledModels) {
  const roundOneMessages = [];

  const roundOneReplies = await Promise.all(
    enabledModels.map((model) => generateModelReply(state, model, hostText, 1, roundOneMessages))
  );

  enabledModels.forEach((model, index) => {
    const message = addMessage(state, {
      kind: "model",
      modelId: model.id,
      author: model.name,
      provider: model.provider,
      text: roundOneReplies[index],
      color: model.color
    });
    roundOneMessages.push(message);
  });

  if (state.settings.discussionRounds < 2 || enabledModels.length < 2) return;

  const roundTwoReplies = await Promise.all(
    enabledModels.map((model, index) => {
      const peer = roundOneMessages[(index + enabledModels.length - 1) % enabledModels.length];
      return generateModelReply(state, model, hostText, 2, [peer]);
    })
  );

  enabledModels.forEach((model, index) => {
    addMessage(state, {
      kind: "model",
      modelId: model.id,
      author: model.name,
      provider: model.provider,
      text: roundTwoReplies[index],
      color: model.color
    });
  });
}

function captureMemory(state, text) {
  const patterns = [
    /remember(?: that|:)?\s+(.+)/i,
    /keep in mind(?: that|:)?\s+(.+)/i,
    /i prefer\s+(.+)/i,
    /my preference is\s+(.+)/i
  ];

  const found = patterns
    .map((pattern) => text.match(pattern))
    .find(Boolean);

  if (!found || !found[1]) return;

  const memoryText = shorten(found[1].trim(), 220);
  if (!memoryText || state.memories.some((memory) => memory.text === memoryText)) return;

  state.memories.push({
    id: uid("mem"),
    text: memoryText,
    source: "auto-capture",
    createdAt: Date.now()
  });

  addMessage(state, {
    kind: "system",
    author: "Memory",
    text: `Saved memory: ${memoryText}`,
    color: "#9b7cff"
  });
}

function compactContext(state, { force }) {
  const activeTokens = estimateActiveTokens(state);
  const shouldCompact = force || activeTokens > state.settings.tokenBudget || state.messages.length > 18;
  if (!shouldCompact || state.messages.length < 8) return false;

  const keepCount = 8;
  const compactedMessages = state.messages.slice(0, -keepCount);
  if (compactedMessages.length === 0) return false;

  state.summaries.push({
    id: uid("sum"),
    createdAt: Date.now(),
    messageCount: compactedMessages.length,
    text: summarizeMessages(compactedMessages)
  });

  state.messages = state.messages.slice(-keepCount);
  state.messages.unshift({
    id: uid("msg"),
    kind: "system",
    author: "Context Compressor",
    text: `Compressed ${compactedMessages.length} older messages into a carry-forward summary.`,
    color: "#9b7cff",
    createdAt: Date.now()
  });

  return true;
}

function estimateActiveTokens(state) {
  const activeText = [
    ...state.messages.map((message) => message.text),
    ...state.memories.map((memory) => memory.text),
    ...state.summaries.slice(-4).map((summary) => summary.text)
  ].join(" ");
  return estimateTokens(activeText);
}

async function generateModelReply(state, model, hostText, round, peerMessages) {
  const context = buildPromptContext(state, hostText);

  if (hasRuntimeConfig(model)) {
    try {
      const text = await callModel(model, context, peerMessages);
      return text || "The provider returned an empty response.";
    } catch (error) {
      return `Provider call failed: ${error.message}`;
    }
  }

  const role = classifyPersona(model);
  const hostSummary = summarizeHostText(hostText);
  const newestMemory = context.memories[context.memories.length - 1];
  const memoryLine = newestMemory
    ? `I will keep "${shorten(newestMemory.text, 96)}" in scope.`
    : "I do not have durable memory yet, so I will keep this response self-contained.";

  if (round === 2 && peerMessages.length > 0) {
    const peer = peerMessages[0];
    return [
      `Reacting to ${peer.author}: ${reactionVerb(role)}.`,
      `The useful next move is ${nextMoveForRole(role, hostText)}.`,
      `My concern is ${riskForRole(role, hostText)}.`,
      memoryLine
    ].join(" ");
  }

  return [
    `${openerForRole(role)} ${hostSummary}`,
    `I would prioritize ${priorityForRole(role, hostText)}.`,
    `Watch for ${riskForRole(role, hostText)}.`,
    memoryLine
  ].join(" ");
}

function buildPromptContext(state, hostText) {
  return {
    hostMessage: hostText,
    memories: state.memories.slice(-8),
    summaries: state.summaries.slice(-4),
    recentMessages: state.messages.slice(-10)
  };
}

function classifyPersona(model) {
  const haystack = `${model.name} ${model.persona}`.toLowerCase();
  if (haystack.includes("engineer") || haystack.includes("architecture")) return "engineer";
  if (haystack.includes("critic") || haystack.includes("risk") || haystack.includes("adversarial")) return "critic";
  if (haystack.includes("product") || haystack.includes("strategy") || haystack.includes("user")) return "strategist";
  if (haystack.includes("design") || haystack.includes("ux")) return "designer";
  return "generalist";
}

function summarizeHostText(text) {
  const cleaned = text.replace(/\s+/g, " ").trim();
  const isQuestion = cleaned.includes("?");
  const lead = shorten(cleaned, 128);
  return isQuestion
    ? `I hear the host asking: "${lead}"`
    : `I hear the host proposing: "${lead}"`;
}

function openerForRole(role) {
  const map = {
    engineer: "From an implementation angle,",
    critic: "The weak point to test is this:",
    strategist: "From a product angle,",
    designer: "From the room experience angle,",
    generalist: "My read is:"
  };
  return map[role] || map.generalist;
}

function priorityForRole(role, text) {
  const lower = text.toLowerCase();
  if (role === "engineer") {
    if (lower.includes("api") || lower.includes("model")) return "a clean adapter boundary before provider-specific API calls";
    if (lower.includes("memory")) return "a visible memory store plus deterministic compression rules";
    return "a small end-to-end room loop with persisted state";
  }
  if (role === "critic") {
    return "evidence that the live-room metaphor improves decisions instead of becoming noisy chat";
  }
  if (role === "designer") {
    return "clear turn-taking, visible model identities, and controls that make the host feel in charge";
  }
  if (role === "strategist") {
    return "the host workflow: ask, compare model viewpoints, save useful memory, then decide";
  }
  return "one concrete workflow that proves the room can create better answers";
}

function riskForRole(role, text) {
  const lower = text.toLowerCase();
  if (role === "engineer") {
    return lower.includes("context")
      ? "summary drift if the compressor hides decisions that should stay explicit"
      : "state divergence between transcript, memory, and provider calls";
  }
  if (role === "critic") {
    return "adding many models without a moderator, which can create volume without judgment";
  }
  if (role === "designer") {
    return "overloading the host with configuration before the room has earned trust";
  }
  if (role === "strategist") {
    return "shipping provider setup before the core discussion loop feels valuable";
  }
  return "unclear ownership of what should become memory";
}

function nextMoveForRole(role, text) {
  if (role === "engineer") return "define the shared room state and adapter contract, then reuse it across platforms";
  if (role === "critic") return "force each model to state a decision, a risk, and what evidence would change its mind";
  if (role === "designer") return "make model presence, speaking order, and saved memory visible without extra explanation";
  if (role === "strategist") return "ship the offline simulation first and use it to validate the host workflow";
  return `turn "${shorten(text, 56)}" into a decision-oriented discussion prompt`;
}

function reactionVerb(role) {
  const map = {
    engineer: "I agree with the direction, but the data contract needs to be explicit",
    critic: "I disagree unless the product can prove the extra voices create sharper decisions",
    strategist: "I would narrow that into a first-session success metric",
    designer: "I would make that visible as a host control, not a hidden system behavior",
    generalist: "I would turn that into a concrete next step"
  };
  return map[role] || map.generalist;
}

function summarizeMessages(messages) {
  const hostMessages = messages.filter((message) => message.kind === "host").map((message) => message.text);
  const modelMessages = messages.filter((message) => message.kind === "model");
  const topics = topKeywords(messages.map((message) => message.text).join(" "));
  const openQuestions = hostMessages.filter((text) => text.includes("?")).map((text) => shorten(text, 100));
  const positions = {};

  modelMessages.forEach((message) => {
    if (!positions[message.author]) positions[message.author] = [];
    positions[message.author].push(shorten(message.text, 90));
  });

  const positionLines = Object.entries(positions)
    .map(([author, lines]) => `${author}: ${lines.slice(-2).join(" / ")}`)
    .join("\n");

  return [
    `Topics: ${topics.join(", ") || "general discussion"}`,
    `Host intent: ${hostMessages.slice(-3).map((text) => shorten(text, 120)).join(" | ") || "No host messages."}`,
    `Model positions:\n${positionLines || "No model positions."}`,
    `Open questions: ${openQuestions.join(" | ") || "None captured."}`,
    `Carry-forward memory hints: preserve decisions, unresolved risks, and host preferences from this block.`
  ].join("\n");
}

window.CLRRoomEngine = {
  addMessage,
  runDiscussion,
  captureMemory,
  compactContext,
  estimateActiveTokens
};
})();
