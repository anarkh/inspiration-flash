(() => {
const { DEFAULT_MODELS } = window.CLRDefaults;
const { loadState, persistState } = window.CLRStorage;
const { addMessage, captureMemory, compactContext, runDiscussion } = window.CLRRoomEngine;
const { render } = window.CLRRender;
const { clone, uid } = window.CLRUtils;

const els = {};
let state;

document.addEventListener("DOMContentLoaded", init);

async function init() {
  bindElements();
  bindEvents();
  state = await loadState();
  els.tokenBudget.value = String(state.settings.tokenBudget);
  renderApp();
}

function bindElements() {
  [
    "liveStatus",
    "modelCount",
    "memoryCount",
    "enabledCount",
    "tokenEstimate",
    "tokenBudgetLabel",
    "summaryCount",
    "audienceOrbits",
    "modelRail",
    "hostInput",
    "sendMessage",
    "demoMessage",
    "compactNow",
    "clearTranscript",
    "transcript",
    "roomView",
    "configView",
    "memoryView",
    "modelForm",
    "modelFormTitle",
    "editingModelId",
    "modelName",
    "modelProvider",
    "modelId",
    "modelEndpoint",
    "modelApiKey",
    "modelPersona",
    "modelTemperature",
    "modelColor",
    "modelEnabled",
    "resetModelForm",
    "restoreModels",
    "configuredModels",
    "memoryInput",
    "addMemory",
    "exportState",
    "tokenBudget",
    "memoryList",
    "summaryList",
    "clearMemory",
    "clearSummaries"
  ].forEach((id) => {
    els[id] = document.getElementById(id);
  });
}

function bindEvents() {
  document.querySelectorAll(".tab-button").forEach((button) => {
    button.addEventListener("click", () => setView(button.dataset.view));
  });

  els.sendMessage.addEventListener("click", () => submitHostMessage());
  els.hostInput.addEventListener("keydown", (event) => {
    if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
      submitHostMessage();
    }
  });
  els.demoMessage.addEventListener("click", seedDemoMessage);
  els.compactNow.addEventListener("click", () => {
    compactContext(state, { force: true });
    saveAndRender();
  });
  els.clearTranscript.addEventListener("click", clearTranscript);

  els.modelForm.addEventListener("submit", saveModelFromForm);
  els.resetModelForm.addEventListener("click", resetModelForm);
  els.restoreModels.addEventListener("click", restoreDefaultModels);
  els.configuredModels.addEventListener("click", handleModelAction);

  els.addMemory.addEventListener("click", addMemoryFromInput);
  els.exportState.addEventListener("click", exportStateToMemoryBox);
  els.tokenBudget.addEventListener("input", () => {
    state.settings.tokenBudget = Number(els.tokenBudget.value);
    saveAndRender();
  });
  els.memoryList.addEventListener("click", handleMemoryAction);
  els.clearMemory.addEventListener("click", clearMemory);
  els.clearSummaries.addEventListener("click", clearSummaries);
}

function setView(view) {
  state.view = view;
  document.querySelectorAll(".tab-button").forEach((button) => {
    button.classList.toggle("active", button.dataset.view === view);
  });
  [els.roomView, els.configView, els.memoryView].forEach((viewEl) => {
    viewEl.classList.toggle("active-view", viewEl.id === `${view}View`);
  });
  persistState(state).catch(reportPersistError);
}

async function submitHostMessage() {
  if (els.sendMessage.disabled) return;
  const text = els.hostInput.value.trim();
  if (!text) return;

  els.sendMessage.disabled = true;
  els.sendMessage.textContent = "Calling...";

  try {
    const enabledModels = state.models.filter((model) => model.enabled);
    addMessage(state, {
      kind: "host",
      author: "Host",
      text,
      color: "#4fd18b"
    });

    captureMemory(state, text);

    if (enabledModels.length === 0) {
      addMessage(state, {
        kind: "system",
        author: "Room Director",
        text: "No audience models are enabled. Enable a model in Config before starting a discussion.",
        color: "#9b7cff"
      });
    } else {
      await runDiscussion(state, text, enabledModels);
    }

    els.hostInput.value = "";
    compactContext(state, { force: false });
    saveAndRender();
  } finally {
    els.sendMessage.disabled = false;
    els.sendMessage.textContent = "Go Live";
  }
}

function seedDemoMessage() {
  els.hostInput.value =
    "We are designing Cyber Live Room. Debate the MVP scope: model audience, configurable providers, long-term memory, and context compression. What should ship first?";
  els.hostInput.focus();
}

function saveModelFromForm(event) {
  event.preventDefault();
  const id = els.editingModelId.value || uid("model");
  const model = {
    id,
    name: els.modelName.value.trim(),
    provider: els.modelProvider.value,
    modelId: els.modelId.value.trim() || "simulation-model",
    endpoint: els.modelEndpoint.value.trim(),
    apiKey: els.modelApiKey.value.trim(),
    persona: els.modelPersona.value.trim(),
    temperature: Number(els.modelTemperature.value),
    color: els.modelColor.value,
    enabled: els.modelEnabled.checked
  };

  if (!model.name || !model.persona) return;

  const index = state.models.findIndex((item) => item.id === id);
  if (index >= 0) {
    state.models[index] = model;
  } else {
    state.models.push(model);
  }

  resetModelForm();
  saveAndRender();
}

function handleModelAction(event) {
  const button = event.target.closest("button[data-action]");
  if (!button) return;

  const model = state.models.find((item) => item.id === button.dataset.id);
  if (!model) return;

  if (button.dataset.action === "edit") {
    fillModelForm(model);
    return;
  }

  if (button.dataset.action === "toggle") {
    model.enabled = !model.enabled;
  }

  if (button.dataset.action === "delete") {
    state.models = state.models.filter((item) => item.id !== model.id);
  }

  saveAndRender();
}

function fillModelForm(model) {
  els.modelFormTitle.textContent = "Edit Model";
  els.editingModelId.value = model.id;
  els.modelName.value = model.name;
  els.modelProvider.value = model.provider;
  els.modelId.value = model.modelId;
  els.modelEndpoint.value = model.endpoint;
  els.modelApiKey.value = model.apiKey || "";
  els.modelPersona.value = model.persona;
  els.modelTemperature.value = String(model.temperature);
  els.modelColor.value = model.color;
  els.modelEnabled.checked = model.enabled;
}

function resetModelForm() {
  els.modelFormTitle.textContent = "Add Model";
  els.modelForm.reset();
  els.editingModelId.value = "";
  els.modelTemperature.value = "0.7";
  els.modelColor.value = "#39a0ff";
  els.modelEnabled.checked = true;
}

function restoreDefaultModels() {
  state.models = clone(DEFAULT_MODELS);
  saveAndRender();
}

function addMemoryFromInput() {
  const text = els.memoryInput.value.trim();
  if (!text) return;
  state.memories.push({
    id: uid("mem"),
    text,
    source: "manual",
    createdAt: Date.now()
  });
  els.memoryInput.value = "";
  saveAndRender();
}

function handleMemoryAction(event) {
  const button = event.target.closest("button[data-id]");
  if (!button) return;
  state.memories = state.memories.filter((memory) => memory.id !== button.dataset.id);
  saveAndRender();
}

function exportStateToMemoryBox() {
  const snapshot = {
    models: state.models,
    memories: state.memories,
    summaries: state.summaries,
    messages: state.messages,
    settings: state.settings
  };
  els.memoryInput.value = JSON.stringify(snapshot, null, 2);
}

function clearTranscript() {
  state.messages = [];
  saveAndRender();
}

function clearMemory() {
  state.memories = [];
  saveAndRender();
}

function clearSummaries() {
  state.summaries = [];
  saveAndRender();
}

function saveAndRender() {
  renderApp();
  persistState(state).catch(reportPersistError);
}

function renderApp() {
  render(state, els);
}

function reportPersistError(error) {
  console.error("Failed to persist local state", error);
}
})();
